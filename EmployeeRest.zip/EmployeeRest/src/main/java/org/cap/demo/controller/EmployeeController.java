package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Employee;
import org.cap.demo.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/emp/v1")
public class EmployeeController {
	
	@Autowired
	private IEmployeeService employeeService;

	@ApiOperation(value = "FindEmployeeById",notes = "find employee for the given employee Id"
			,nickname = "searchEmployeeById")
	@ApiResponses(value = {
			@ApiResponse(code = 404,message = "Employee Id not found!"),
			@ApiResponse(code = 500,message = "Invalid Input!")
	})
	@ApiParam(value = "empId",required = true,defaultValue = "1000")
	@GetMapping("/employees/{empId}")
	public ResponseEntity<Employee> findEmployee(@PathVariable("empId") Integer empId){
		Employee employee= employeeService.findEmployee(empId);
		if(employee==null )
			return new ResponseEntity("Sorry! Employee ID Not Found!", 
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		List<Employee> employees= employeeService.getAllEmployees();
		if(employees==null || employees.isEmpty())
			return new ResponseEntity("Sorry! No Employees Available!", 
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}
	
	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployee(
			@RequestBody Employee employee){
		List<Employee> employees= employeeService.saveEmployee(employee);
		if(employees==null || employees.isEmpty())
			return new ResponseEntity("Sorry! Insertion error!", 
					HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<List<Employee>>(employees,HttpStatus.OK);
	}
	
}
