package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAddressDao;
import org.cap.demo.dao.IEmployeeDao;
import org.cap.demo.model.Address;
import org.cap.demo.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements IEmployeeService{

	@Autowired
	private IEmployeeDao employeeDao;
	@Autowired
	private IAddressDao addressDao;
	
	@Override
	public List<Employee> getAllEmployees() {
		
		return employeeDao.findAll();
	}

	@Override
	public List<Employee> saveEmployee(Employee employee) {
		
		employeeDao.save(employee);
		
		for(Address address:employee.getAddresses()) {
			address.setEmployee(employee);
			addressDao.save(address);
		}
		
		return employeeDao.findAll();
	}

	@Override
	public Employee findEmployee(Integer empId) {
		
		return employeeDao.getOne(empId);
	}

}
